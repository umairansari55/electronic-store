<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Electronic Store</title>
    <!-- Link css file here-->
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <!-- Nav bar section starts here-->
    <section class="navbar">
        <div class="container">
            <div class="logo">
                <a href="#" title="Logo">
            <img src="images/logo.jpg" class="img-responsive">
                </a>
            </div>
            <div class="products text-right">
                <ul>
                    <li>
                        <a href="<?php echo 'http://localhost/e-store/';?>">&#9750 Home</a>
                    </li>
                    <li>
                        <a href="<?php echo 'http://localhost/e-store/';?>catagories.php">&#9870 Categories</a>
                    </li>
                    <li>
                        <a href="<?php echo 'http://localhost/e-store/';?>products.php">&#9738 Products</a>
                    </li>
                    <li>
                        <a href="">&#9743 Contact</a>
                    </li>
                    <li>
                        <a href="<?php echo 'http://localhost/e-store/';?>admin/index.php"> &#10020Admin</a>
                    </li>
                </ul>
            </div>
            <div class="clearfix">

            </div>
    </section>