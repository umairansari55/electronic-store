<?php
        include('partials-front/menu.php');
    ?>
    <?php
        //check whether product id is set or not
        if(isset($_GET['product_id']))
        {
            //get product id and details of selected product
            $product_id = $_GET['product_id'];
            $conn = mysqli_connect('localhost','root','') or die(mysqli_error()); //Database connection
            $db_select = mysqli_select_db($conn,'estore-order') or die(mysqli_error());
            $sql = "SELECT * FROM tbl_product WHERE id=$product_id";
            //execute the query
            $res = mysqli_query($conn, $sql);
            //count the rows
            $count = mysqli_num_rows($res);
            //check whether the data is available or not
            if($count==1)
            {
                //we have data
                //get data from database
                $row = mysqli_fetch_assoc($res);
                $title = $row['title'];
                $price = $row['price'];
                $image_name = $row['image_name'];
            }
            else
            {
                //product not available
                //redirect to homepage
                header("location:".'http://localhost/e-store/');
            }
        }
        else
        {
            //redirect to homepage
            header("location:".'http://localhost/e-store/');
        }
    ?>
   
    <!-- Product Search section starts here-->
    <section class="Product-Search text-center">
        <div class="container">
            <h2 class="text-center text-cyan">Fill this form to confirm your order.</h2>

            <form action="" method="POST" class="order">
                <fieldset>
                    <legend>Selected Product</legend>

                    <div class="product-img">
                        <?php
                            //check whether mage is available or not
                            if($image_name=="")
                            {
                                //image not available
                                echo "Image not Available";
                            }
                            else
                            {
                                //image available
                                ?>
                                    <img src="<?php echo 'http://localhost/e-store/';?>images/product/<?php echo $image_name;?>"class="img-responsive img-curve">
                                <?php
                            }
                        ?>
                        
                    </div>
    
                    <div class="product-desc">
                        <h3><?php echo $title;?></h3>
                        <input type="hidden" name = "product" value="<?php echo $title;?>">
                        <p class="product-price">Rs:<?php echo $price;?></p>
                        <input type="hidden" name="price" value="<?php echo $price;?>">

                        <div class="order-label">Quantity</div>
                        <input type="number" name="qty" class="input-responsive" value="1" required>
                        
                    </div>

                </fieldset>
                
                <fieldset>
                    <legend>Delivery Details</legend>
                    <div class="order-label">Full Name</div>
                    <input type="text" name="full-name" placeholder="Enter Your Full Name" class="input-responsive" required>

                    <div class="order-label">Phone Number</div>
                    <input type="tel" name="contact" placeholder="E.g. 03XX-XXXXXXX" class="input-responsive" required>

                    <div class="order-label">Email</div>
                    <input type="email" name="email" placeholder="Enter your e-mail" class="input-responsive" required>

                    <div class="order-label">Address</div>
                    <textarea name="address" rows="10" placeholder="E.g. Street, City, Country" class="input-responsive" required></textarea>

                    <input type="submit" name="submit" value="Confirm Order" class="btn btn-primary">
                </fieldset>

            </form>
            <?php

                //check whether the submit button is clicked or not
                if(isset($_POST['submit']))
                {
                    //get all details from the form
                    $product = $_POST['product'];
                    $price = $_POST['price'];
                    $qty = $_POST['qty'];
                    $total = $price * $qty;
                    $order_date = date("Y-m-d h:i:sa");
                    $status = "ordered";
                    $customer_name= $_POST['full-name'];
                    $customer_contact = $_POST['contact'];
                    $customer_email = $_POST['email'];
                    $customer_address = $_POST['address'];

                    //save the order in database
                    $conn = mysqli_connect('localhost','root','') or die(mysqli_error()); //Database connection
                    $db_select = mysqli_select_db($conn,'estore-order') or die(mysqli_error());
                    $sql2 = "INSERT INTO tbl_order SET
                    product = '$product',
                    price = $price,
                    qty = $qty,
                    total = $total,
                    order_date = '$order_date',
                    status = '$status',
                    customer_name = '$customer_name',
                    customer_contact = '$customer_contact',
                    customer_email = '$customer_email',
                    customer_address = '$customer_address'
                    ";
                    //execute the query
                    $res2=mysqli_query($conn,$sql2);
                    if($res2==true)
                    {
                        //query executed and order saved
                        header("location:".'http://localhost/e-store/');

                    }
                    else
                    {
                        //failed to save order

                    }
                }


            ?>
        </div>
    </section>

    

    <?php
        include('partials-front/footer.php');
    ?>
