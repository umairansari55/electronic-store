<html>
    <head>
        <title>Electronic Store Website - Home Page</title>
        <link rel="stylesheet" href="../css/admin.css">
    </head>
    <body>
        <!-- Product section starts-->
        <div class="product text-center">
            <div class="wrapper">
                <ul>
                    <li><a href="index.php">&#9750 Home</a></li>
                    <li><a href="manage-admin.php">&#10020 Admin</a></li>
                    <li><a href="manage-category.php">&#9870 Category</a></li>
                    <li><a href="manage-product.php">&#9738 Product</a></li>
                    <li><a href="manage-order.php">&#9743Order</a></li>
                    <li><a href="logout.php">&#9737 Logout</a></li>

                </ul>
                

            </div>


        </div>
         <!-- Main-content section starts-->
         <div class="main-content">
            <div class="wrapper">
                <h1>Update Category</h1>
                <br><br>
                <?php
                $conn = mysqli_connect('localhost','root','') or die(mysqli_error()); //Database connection
                $db_select = mysqli_select_db($conn,'estore-order') or die(mysqli_error());

                //check whether the id is set or not
                if(isset($_GET['id']))
                {
                    //get the id and all other details
                    //echo "getting the data";
                    $id = $_GET['id'];
                    //create SQL query 
                    $sql = "SELECT * FROM tbl_category WHERE id=$id";

                    //execute the query
                    $res = mysqli_query($conn, $sql);
                    //check whether the data is available or not
                    $count = mysqli_num_rows($res);
                    if($count==1)
                  {
                      //Get the details
                      //echo "Category Availabe";
                      $row=mysqli_fetch_assoc($res);
                      $title = $row['title'];
                      $current_image = $row['image_name'];
                      $featured = $row['featured'];
                      $active= $row['active'];
                  }
                  else
                  {
                      //Redirect to Manage-admin Page
                      header('location:'."http://localhost/e-store/".'admin/manage-category.php');

                  }
                }
                else
                {
                    //redirect to manage category
                    header("location:".'http://localhost/e-store/'.'admin/manage-category.php');

                }
                ?>
                <form action="" method="POST" enctype="multipart/form-data">
                <table class="tbl-30">
                    <tr>
                        <td>Title:</td>
                        <td>
                            <input type="text" name="title" value="<?php echo $title;?>">
                        </td>
                    </tr>
                    <tr>
                        <td>Current Image:</td>
                        <td>
                            <?php
                            if($current_image!="")
                            {
                                //Display the image
                                ?>
                                <img src="<?php echo 'http://localhost/e-store/';?>images/category/<?php echo $current_image;?>" width="150px" >
                                <?php
                            }
                            else
                            {
                                //Display Message
                                echo "Image not added";
                            }
                            
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <td>New Image</td>
                        <td>
                            <input type="file" name="image">
                        </td>
                    </tr>
                    <tr>
                            <td>Featured:</td>
                            <td>
                                <input <?php if($featured=="Yes"){echo "checked";} ?> type="radio" name="featured" value="Yes"> Yes
                                <input <?php if($featured=="No"){echo "checked";} ?> type="radio" name="featured" value="No"> No
                                

                            </td>
                        </tr>
                        <tr>
                            <td>Active:</td>
                            <td>
                                <input <?php if($active=="Yes"){echo "checked";} ?> type="radio" name="active" value="Yes"> Yes
                                <input <?php if($active=="No"){echo "checked";} ?> type="radio" name="active" value="No"> No

                            </td>
                        </tr>
                        <tr>
                            <td>
                                <input type="hidden" name="current_image" value="<?php echo $current_image; ?>">
                                <input type="hidden" name="id" value="<?php echo $id; ?>">
                            <input type="submit" name="submit" value="Update Category" class="btn-secondary">
                            </td>
                        </tr>

                </table>
                </form>
                <?php
        //Check whether the submit button is clicked or not
        if(isset($_POST['submit']))
        {
            //echo "Button clicked";
            //get all the values from form to update
            $id = $_POST['id'];
            $title = $_POST['title'];
            $current_image = $_POST['image_name'];
            $featured = $_POST['featured'];
            $active= $_POST['active'];

            //updating new image if selected
            //check whether image is selected or not
            if(isset($_FILES['image']['name']))
            {
                //get the image details
                $image_name=$_FILES['image']['name'];
                //check whether the image is available or not
                if($image_name!="")
                {
                    //image available
                    //upload the image
                    //auto rename our Image
                    //get the extension of our image (jpg, png, gif, etc)
                    $ext=end(explode('.' , $image_name));
                    //rename the image 
                    $image_name = "Product_Category_".rand(000, 999).'.'.$ext;
                    $source_path=$_FILES['image']['tmp_name'];
                    $destination_path="../images/category/".$image_name;
                    //finally upload the image                       
                    $upload= move_uploaded_file($source_path, $destination_path);
    
                    //check whether is uploaded or not
                    //and if image is not uploaded then we will stop the process and redirect to homepage
                    if($upload==false)
                    {
                        header("location:".'http://localhost/e-store/'.'admin/manage-category.php');
                        //stop the process
                        die();
    
                    }
                        //remove the current image if image is available
                            if($current_image!="") 
                            {
                                $remove_path = "../images/category/".$current_image;
                            $remove= unlink($remove_path);
                            //check whether the image is removed or not
                            if($remove==false)
                            {
                                //failed to remove the image
                                //redirect to manage category page
                                header("location:".'http://localhost/e-store/'.'admin/manage-category.php');
                                die();


                            }
                        }
                        
                    }
                    else
                    {
                        $image_name= $current_image;
                    }
                }
                else
                {
                    $image_name= $current_image;
                }

            //update the Database
            $sql2 = "UPDATE tbl_category SET
            title = '$title',
            image_name='$image_name',
            featured = '$featured',
            active = '$active'
            WHERE id=$id
            ";
            //execute the query
            $res2 = mysqli_query($conn, $sql2);
            //check whether query executed or not
            if($res2==true)
            {
                //Category updated
                header('location:'."http://localhost/e-store/".'admin/manage-category.php');

            }
            else
            {
                //Failed to update category
            }

        }
        ?>
            </div>
        </div>
         <!-- Footer section starts-->
         <div class="footer">
        <div class="wrapper">
                <p class="text-center">
                    2021 All rights reserved. Developed By<a href="#">Muhammad Umair</a>
                </p>

                </div>
            

        </div>
    </body>
</html>