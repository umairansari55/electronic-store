<?php

$conn = mysqli_connect('localhost','root','') or die(mysqli_error()); //Database connection
$db_select = mysqli_select_db($conn,'estore-order') or die(mysqli_error());

//Get the id of Admin to be deleted
$id = $_GET['id'];

//create SQL query to delete Admin
$sql = "DELETE FROM tbl_admin WHERE id=$id";

//execute the query
$res = mysqli_query($conn, $sql);
//check whether the query executed successfully or not
if($res==TRUE)
{
    //QUERY EXECUTED successfully and admin deleted
    //echo "Admin Deleted";
    header('location:'."http://localhost/e-store/".'admin/manage-admin.php');
}
else
{
    //Failed to Delete Admin
    //echo "Failed to Delete Admin";
}

?>