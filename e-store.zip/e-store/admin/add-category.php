

<html>
    <head>
        <title>Electronic Store Website - Home Page</title>
        <link rel="stylesheet" href="../css/admin.css">
    </head>
    <body>
        <!-- Product section starts-->
        <div class="product text-center">
            <div class="wrapper">
                <ul>
                    <li><a href="index.php">&#9750 Home</a></li>
                    <li><a href="manage-admin.php">&#10020 Admin</a></li>
                    <li><a href="manage-category.php">&#9870 Category</a></li>
                    <li><a href="manage-product.php">&#9738 Product</a></li>
                    <li><a href="manage-order.php">&#9743Order</a></li>
                    <li><a href="logout.php">&#9737 Logout</a></li>

                </ul>
                

            </div>


        </div>
        <!-- Main-content section starts-->
        <div class="main-content">
            <div class="wrapper">
                <h1>Add Category</h1>
                <br>
                <form action="" method="POST" enctype="multipart/form-data">
                    <table class="tbl-30">
                        <tr>
                            <td>Title:</td>
                            <td>
                                <input type="text" name="title" placeholder="Category Title">
                            </td>
                        </tr>
                        <tr>
                            <td>Select Image:</td>
                            <td>
                                <input type="file" name="image">
                            </td>
                        </tr>
                        <tr>
                            <td>Featured:</td>
                            <td>
                                <input type="radio" name="featured" value="Yes"> Yes
                                <input type="radio" name="featured" value="No"> No

                            </td>
                        </tr>
                        <tr>
                            <td>Active:</td>
                            <td>
                                <input type="radio" name="active" value="Yes"> Yes
                                <input type="radio" name="active" value="No"> No

                            </td>
                        </tr>
                        <tr>
                            <td colspan="2">
                                <input type="submit" name="submit" value="Add Category" class="btn-secondary">
                                
                            </td>
                        </tr>

                    </table>


                </form>
        

               
                <br>
        </div>
        </div>
        <?php
        //Process the value from form and save it in database
        //Check whether the submit button is clicked or not

        if(isset($_POST['submit']))
        {
            //Button clicked
            //"Button Clicked";
            //Get data from form
           $title = $_POST['title']; 
           //for radio input we need to check whether the button is selected or not
           if(isset($_POST['featured']))
           {
               //get value from form
               $featured = $_POST['featured'];
           }
           else
           {
               //set the default value
               $featured = "No";
           }
           if(isset($_POST['active']))
           {
               //get value from form
               $active = $_POST['active'];
           }
           else
           {
               //set the default value
               $active = "No";
           }
           //check whether the image is selected or not and set the value for image name aaccordingly
           //print_r($_FILES['image']);

           //die(); //break the code here
           if(isset($_FILES['image']['name']))
           {
               //upload the image
               //to upload image we need image name source path and destination name
               $image_name=$_FILES['image']['name'];
               //upload image only if image is selected
               if($image_name!="")
               {

               
                    //auto rename our Image
                    //get the extension of our image (jpg, png, gif, etc)
                    $ext=end(explode('.' , $image_name));
                    //rename the image 
                    $image_name = "Product_Category_".rand(000, 999).'.'.$ext;
                    $source_path=$_FILES['image']['tmp_name'];
                    $destination_path="../images/category/".$image_name;
                    //finally upload the image
                    $upload= move_uploaded_file($source_path, $destination_path);

                    //check whether is uploaded or not
                    //and if image is not uploaded then we will stop the process and redirect to homepage
                    if($upload==false)
                    {
                        header("location:".'http://localhost/e-store/'.'admin/add-category.php');
                        //stop the process
                        die();

               }
            }



           }
           else
           {
               //do not upload the image and set image_name value blank
               $image_name = "";
           }
           //SQL query to save data into database
           $sql = "INSERT INTO tbl_category SET
           title = '$title',
           image_name= '$image_name',
           featured = '$featured',
           active = '$active'
           ";
           $conn = mysqli_connect('localhost','root','') or die(mysqli_error()); //Database connection
           $db_select = mysqli_select_db($conn,'estore-order') or die(mysqli_error()); 
           $res = mysqli_query($conn, $sql);
            //Check whether the (query is Executed) data is inserted or not and display appropriate mesaage
            if($res==TRUE)
            {
                //Redirect page to manage-admin
                header("location:".'http://localhost/e-store/'.'admin/manage-category.php');

            }
            else
            {
                //Redirect page to add-admin
                header("location:".'http://localhost/e-store/'.'admin/add-category.php');
            }
        }
        ?>

         <!-- Footer section starts-->
         <div class="footer">
        <div class="wrapper">
                <p class="text-center">
                    2021 All rights reserved. Developed By<a href="#">Muhammad Umair</a>
                </p>

                </div>
            

        </div>
    </body>
</html>