<?php
//include('login-check.php');
?>

<html>
    <head>
        <title>Electronic Store Website - Home Page</title>
        <link rel="stylesheet" href="../css/admin.css">
    </head>
    <body>
        <!-- Product section starts-->
        <div class="product text-center">
            <div class="wrapper">
                <ul>
                    <li><a href="index.php">&#9750 Home</a></li>
                    <li><a href="manage-admin.php">&#10020 Admin</a></li>
                    <li><a href="manage-category.php">&#9870 Category</a></li>
                    <li><a href="manage-product.php">&#9738 Product</a></li>
                    <li><a href="manage-order.php">&#9743Order</a></li>
                    <li><a href="logout.php">&#9737 Logout</a></li>

                </ul>
                

            </div>


        </div>
        <!-- Main-content section starts-->
        <div class="main-content">
            <div class="wrapper">
                <h1>Add Admin</h1>
                <br>
        

               
                <br>

                <form action="" method="POST">
                    <table class="tbl-30">
                        <tr>
                            <td>Full Name </td>
                            <td>
                                <input type="text" name="full_name" placeholder="Enter Your Name">
                            </td>
                        </tr>
                        <tr>
                            <td>Username</td>
                            <td>
                                <input type="text" name="username" placeholder="Your username">
                            </td>
                        </tr>
                        <tr>
                            <td>Password</td>
                            <td>
                                <input type="password" name="password" placeholder="Your Password">
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2">
                                <input type="submit" name="submit" value="Add Admin" class="btn-secondary">
                                
                            </td>
                        </tr>
                    </table>

                </form>
            </div>
        </div>
          <!-- Footer section starts-->
          <div class="footer">
        <div class="wrapper">
                <p class="text-center">
                    2021 All rights reserved. Developed By<a href="#">Muhammad Umair</a>
                </p>

                </div>
            

        </div>
    </body>
</html>
<?php
//Process the value from form and save it in database
//Check whether the submit button is clicked or not

if(isset($_POST['submit']))
{
    //Button clicked
   // echo "Button Clicked";
       //Get data from form
   $full_name = $_POST['full_name'];
   $username = $_POST['username'];
   $password = md5($_POST['password']); //Password Encryption withmd5

        //SQL query to save data into database
   $sql = "INSERT INTO tbl_admin SET
        full_name = '$full_name',
        username = '$username',
        password = '$password'
        ";
        //Execute query and save data in database
        $conn = mysqli_connect('localhost','root','') or die(mysqli_error()); //Database connection
        $db_select = mysqli_select_db($conn,'estore-order') or die(mysqli_error()); 
        $res = mysqli_query($conn,$sql) or die(mysqli_error());
        

        //Check whether the (query is Executed) data is inserted or not and display appropriate mesaage
        if($res==TRUE)
        {
            //DATA inserted
            //echo "Data inserted";
            //Create a session arrival to display a message
            //$_SESSION['add'] = "Admin Added Successfully";
            //Redirect page to manage-admin
            header("location:".'http://localhost/e-store/'.'admin/manage-admin.php');

        }
        else
        {
            //Failed to insert data
            //echo "Failed to insert data";
             //Create a session arrival to display a message
             //$_SESSION['add'] = "Failed to add Admin";
             //Redirect page to add-admin
             header("location:".'http://localhost/e-store/'.'admin/add-admin.php');
        }

}

?>