<!-- Social section starts here-->
<section class="social">
        <div class="container text-center">
            <ul>
                <li>
                    <a href="#"><img src="https://img.icons8.com/color/48/000000/facebook.png"/></a>
                </li>
                <li>
                    <a href="#"><img src="https://img.icons8.com/color/48/000000/instagram-new.png"/></a>
                </li>
                <li>
                    <a href="#"><img src="https://img.icons8.com/color/48/000000/twitter--v1.png"/></a>
                </li>
            </ul>

        </div>
    </section>

    <!-- Footer section starts here-->
    <section class="footer">
        <div class="container text-center">
            <p>
                All rights reserved. Designed By <a href="#">&copyMuhammad Umair</a>
            </p>
        </div>
    </section>

</body>
</html>
