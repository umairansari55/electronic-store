<?php
//Authorization access control
//check whether the user is logged in or not
if(!isset($_SESSION['user'])) 
{
  //user is not loggged in redirect to log in page
  $_SESSION['no-login-message']="error";
  header("location:".'http://localhost/e-store/'.'admin/login.php');

}
?>