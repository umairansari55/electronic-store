<?php
        include('partials-front/menu.php');
    ?>
<?php
    //check whether id is passed or not
    if(isset($_GET['category_id']))
    {
        //category id is set and get the id
        $category_id = $_GET['category_id'];
        //get the category title based on category id
        $conn = mysqli_connect('localhost','root','') or die(mysqli_error()); //Database connection
        $db_select = mysqli_select_db($conn,'estore-order') or die(mysqli_error());
        $sql = "SELECT title FROM tbl_category WHERE id=$category_id";
        //execute the query
        $res = mysqli_query($conn,$sql);
        //get the value from database
        $row = mysqli_fetch_assoc($res);
        //get the title
        $category_title = $row['title'];
    }
    else
    {
        //category id not passed
        //redirect to homepage
        header("location:".'http://localhost/e-store/');
    }
?>
    <!-- Product Search section starts here-->
    <section class="Product-Search text-center">
        <div class="container">
            <h2>Products on <a href="" class="text-white">"<?php echo $category_title;?>"</a></h2>
        </div>
    </section>

    <!-- Product section starts here-->
    <section class="product">
        <div class="container">
            <h2 class="text-center">Explore Products</h2>


            <?php
                //sql query to get products based on selected category
                $conn = mysqli_connect('localhost','root','') or die(mysqli_error()); //Database connection
                $db_select = mysqli_select_db($conn,'estore-order') or die(mysqli_error());
                $sql2 = "SELECT * FROM tbl_product WHERE category_id = $category_id";
                //execute the query
                $res2 = mysqli_query($conn, $sql2);
                //count the rows
                $count2 = mysqli_num_rows($res2);
                //check whether product is available or not
                if($count2>0)
                {
                    //product is available
                    while($row2=mysqli_fetch_assoc($res2))
                    {
                        $id = $row2['id'];
                        $title = $row2['title'];
                        $price = $row2['price'];
                        $description = $row2['description'];
                        $image_name = $row2['image_name'];
                        ?>
                            <div class="product-box">
                                <div class="product-img">
                                    <?php
                                        if($image_name=="")
                                        {
                                            //image not available
                                            echo "Image not Available";
                                        }
                                        else
                                        {
                                            //Image available
                                            ?>
                                            <img src="<?php echo 'http://localhost/e-store/';?>images/product/<?php echo $image_name;?>"class="img-responsive img-curve">
                                            <?php
                                        }
                                    ?>
                                    
                                </div>
                                <div class="product-desc">
                                <h4><?php echo $title;?></h4>
                                <p class="product-price">Rs:<?php echo $price;?></p>
                                <p class="product-detail">
                                    <?php echo $description;?>
                                </p>
                                <br>
                                <a href="<?php echo 'http://localhost/e-store/'; ?>Order.php?product_id=<?php echo $id; ?>" class="btn btn-primary">Order Now</a>
                                </div>
                            </div>
                        <?php

                    }

                }
                else
                {
                    //product not available
                    echo "Product not Available";
                }            
            ?>
                <div class="clearfix"></div>
            </div>
    </section>

    <?php
        include('partials-front/footer.php');
    ?>