<?php
session_start();
$conn = mysqli_connect('localhost','root','') or die(mysqli_error()); //Database connection
$db_select = mysqli_select_db($conn,'estore-order') or die(mysqli_error()); //database selection
include('login-check.php');
?>
<html>
    <head>
        <title>Electronic Store Website - Home Page</title>
        <link rel="stylesheet" href="../css/admin.css">
    </head>
    <body>
        <!-- Product section starts-->
        <div class="product text-center">
            <div class="wrapper">
                <ul>
                    <li><a href="index.php">&#9750 Home</a></li>
                    <li><a href="manage-admin.php">&#10020 Admin</a></li>
                    <li><a href="manage-category.php">&#9870 Category</a></li>
                    <li><a href="manage-product.php">&#9738 Product</a></li>
                    <li><a href="manage-order.php">&#9743Order</a></li>
                    <li><a href="logout.php">&#9737 Logout</a></li>
                </ul>
                

            </div>


        </div>
        <!-- Main-content section starts-->
        <div class="main-content">
        <div class="wrapper">
                <h1>Dashboard</h1>
                <div class="col-4 text-center">
                <?php
                    //sql query
                    $conn = mysqli_connect('localhost','root','') or die(mysqli_error()); //Database connection
                    $db_select = mysqli_select_db($conn,'estore-order') or die(mysqli_error()); //database selection
                    $sql = "SELECT * FROM tbl_category";
                    //execute the query
                    $res= mysqli_query($conn,$sql);
                    //count rows
                    $count=mysqli_num_rows($res);
                    ?>

                    <h1><?php echo $count;?></h1>
                    <br>
                    Categories

                </div>
                <div class="col-4 text-center">
                <?php
                    //sql query
                    $conn = mysqli_connect('localhost','root','') or die(mysqli_error()); //Database connection
                    $db_select = mysqli_select_db($conn,'estore-order') or die(mysqli_error()); //database selection
                    $sql2 = "SELECT * FROM tbl_product";
                    //execute the query
                    $res2= mysqli_query($conn,$sql2);
                    //count rows
                    $count2=mysqli_num_rows($res2);
                    ?>

                    <h1><?php echo $count2;?></h1>
                    <br>
                    Products

                </div>
                <div class="col-4 text-center">
                <?php
                    //sql query
                    $conn = mysqli_connect('localhost','root','') or die(mysqli_error()); //Database connection
                    $db_select = mysqli_select_db($conn,'estore-order') or die(mysqli_error()); //database selection
                    $sql3 = "SELECT * FROM tbl_order";
                    //execute the query
                    $res3= mysqli_query($conn,$sql3);
                    //count rows
                    $count3=mysqli_num_rows($res3);
                    ?>

                    <h1><?php echo $count3;?></h1>
                    <br>
                    Total Orders

                </div>
                <div class="col-4 text-center">
                    <?php
                        //sql query
                        $conn = mysqli_connect('localhost','root','') or die(mysqli_error()); //Database connection
                        $db_select = mysqli_select_db($conn,'estore-order') or die(mysqli_error()); //database selection
                        //aggregate function in sql
                        $sql4="SELECT SUM(total) AS Total FROM tbl_order";
                         //execute the query
                        $res4= mysqli_query($conn,$sql4);
                        //get the value
                        $row = mysqli_fetch_assoc($res4);
                            //get total revenue
                            $total_revenue = $row['Total'];

                        

                    ?>
                    <h1>Rs:<?php echo $total_revenue;?></h1>
                    <br>
                    Revenue Generated

                </div>
                <div class="clearfix"></div>

                </div>
            

        </div>
        <!-- Footer section starts-->
        <div class="footer">
        <div class="wrapper">
                <p class="text-center">
                    2021 All rights reserved. Developed By<a href="#">Muhammad Umair</a>
                </p>

                </div>
            

        </div>
    </body>
</html>