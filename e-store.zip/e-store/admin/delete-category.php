<?php

$conn = mysqli_connect('localhost','root','') or die(mysqli_error()); //Database connection
$db_select = mysqli_select_db($conn,'estore-order') or die(mysqli_error());

if(isset($_GET['id']) AND isset($_GET['image_name']))
{
    $id = $_GET['id'];
    $image_name = $_GET['image_name'];

    //remove the physical image file is available
    if($image_name !="")
    {
        //image is available so remove it
        $path = "../images/category/".$image_name;
        //now remove the image
        $remove = unlink($path);
        //if failed to remove the image then stop  the process and redirect to manage category page
        if($remove==false)
        {
        header("location:".'http://localhost/e-store/'.'admin/manage-category.php');
        die();
        }
    }

    //delete the data from database
    //create SQL query to delete Admin
    $sql = "DELETE FROM tbl_category WHERE id=$id";
    //execute the query
    $res = mysqli_query($conn, $sql);

    if($res==TRUE)
    {
        //QUERY EXECUTED successfully and category deleted
        //echo "category Deleted";
        header('location:'."http://localhost/e-store/".'admin/manage-category.php');
    }
    else
    {
        //Failed to Delete category
        //echo "Failed to Delete product";
    }
}
else
{
  //redirect to manage category page
  header('location:'."http://localhost/e-store/".'admin/manage-category.php');
}
?>