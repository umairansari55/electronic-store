<?php
        include('partials-front/menu.php');
?>
   
    <!-- Product Search section starts here-->
    <section class="Product-Search text-center">
        <div class="container">
            <h2>Products on Your Search <a href="#" class="text-white"></a></h2>
        </div>
    </section>
  <!-- Product section starts here-->
    <section class="product">
        <div class="container">
            <h2 class="text-center">Explore Products</h2>
            <?php
                //get the search keyword
                $search= $_POST['search'];
                //sql query to get food based on search keyword
                $conn = mysqli_connect('localhost','root','') or die(mysqli_error()); //Database connection
                $db_select = mysqli_select_db($conn,'estore-order') or die(mysqli_error());
                $sql = "SELECT * FROM tbl_product WHERE title LIKE '%$search%' OR description LIKE '%$search%'";
                //execute the query
                $res = mysqli_query($conn, $sql);
                //count rows
                $count = mysqli_num_rows($res);
                //check whether product available or not
                if($count>0)
                {
                    //product available
                    while($row=mysqli_fetch_assoc($res))
                    {
                        //get the details
                        $id = $row['id'];
                        $title = $row['title'];
                        $price = $row['price'];
                        $description = $row['description'];
                        $image_name = $row['image_name'];
                        ?>
                        <div class="product-box">
                            <div class="product-img">
                                <?php
                                    
                                    //check whether the image is available or not
                                    if($image_name=="")
                                    {
                                        //display the message
                                        echo "image not available";
                                    }
                                    else
                                    {
                                        //image available
                                        ?>
                                            <img src="<?php echo 'http://localhost/e-store/';?>images/product/<?php echo $image_name;?>" alt="" class="img-responsive">
                                        <?php
                                    }
                                ?>
                                
                            </div>
                            <div class="product-desc">
                            <h4><?php echo $title;?></h4>
                            <p class="product-price">Rs:<?php echo $price;?></p>
                            <p class="product-detail">
                                <?php echo $description;?>
                            </p>
                            <br>
                            <a href="#" class="btn btn-primary">Order Now</a>
                            </div>
                            </div>

                        <?php
                    }
                }
                else
                {
                    //product not available
                    echo "Product Not Found";
                }

            ?>           
                <div class="clearfix"></div>
            </div>
    </section>

    <?php
        include('partials-front/footer.php');
    ?>