<?php
//include('login-check.php');
session_start();
$conn = mysqli_connect('localhost','root','') or die(mysqli_error()); //Database connection
$db_select = mysqli_select_db($conn,'estore-order') or die(mysqli_error()); //database selection
?>
<html>
    <head>
        <title>Electronic Store Website - Home Page</title>
        <link rel="stylesheet" href="../css/admin.css">
    </head>
    <body>
        <!-- Product section starts-->
        <div class="product text-center">
            <div class="wrapper">
                <ul>
                    <li><a href="index.php">&#9750 Home</a></li>
                    <li><a href="manage-admin.php">&#10020 Admin</a></li>
                    <li><a href="manage-category.php">&#9870 Category</a></li>
                    <li><a href="manage-product.php">&#9738 Product</a></li>
                    <li><a href="manage-order.php">&#9743Order</a></li>
                    <li><a href="logout.php">&#9737 Logout</a></li>
                </ul>
                

            </div>


        </div>
            
             <!-- Main-content section starts-->
             <div class="main-content">
                 <div class="wrapper">
                 <h1>Manage Category</h1>
                 <br>
                <br>
                <br>

               <a href="<?php echo "http://localhost/e-store/";?>admin/add-category.php" class="btn-primary">Add Category</a>
                <br>
                <br>
                <br>
                <table class="tbl-full">
                   <tr>
                       <th>S.No</th>
                       <th>Title</th>
                       <th>Image</th>
                       <th>Featured</th>
                       <th>Active</th>
                       <th>Actions</th>
                   </tr>
                   <?php
                    $conn = mysqli_connect('localhost','root','') or die(mysqli_error()); //Database connection
                    $db_select = mysqli_select_db($conn,'estore-order') or die(mysqli_error()); 
                   //Query to get all categories from database
                   $sql = "SELECT * FROM tbl_category";
                   //Execute the query
                   $res = mysqli_query($conn, $sql);

                   //count rows
                   $count= mysqli_num_rows($res);

                   //create a variable and assign the value
                   $sn=1; 

                   //check whether we have data in database or not
                   if($count>0)
                       {
                           //we have data in database
                           //get data and display
                           while($row=mysqli_fetch_assoc($res))
                           {
                               //using while loop to get all the data from database
                               //and while looop will run as long we have data in database
                               //get indivisual data
                               $id = $row['id'];
                               $title = $row['title'];
                               $image_name = $row['image_name'];
                               $featured = $row['featured'];
                               $active = $row['active'];

                               ?>

                    
                    <tr>
                       <td><?php echo $sn++;?>.</td>
                       <td><?php echo $title;?></td>
                       <td>
                           <?php 
                           //check whether image name i available or not
                           if($image_name!="")
                           {
                               //display the image
                               ?>

                               <img src="<?php echo "http://localhost/e-store/";?>images/category;?><?php echo $image_name;?>" width="100px">

                               <?php

                           }
                           else
                           {
                               //display the message
                               echo "Image not added";
                           }



                           ?>
                       
                    </td>
                       <td><?php echo $featured;?></td>
                       <td><?php echo $active;?></td>
                       <td>
                           <a href="<?php echo "http://localhost/e-store/"; ?>admin/update-category.php?id=<?php echo $id;?>" class="btn-secondary">Update Category</a>
                           <a href="<?php echo "http://localhost/e-store/"; ?>admin/delete-category.php?id=<?php echo $id; ?>&image_name=<?php echo $image_name;?>" class="btn-danger">Delete Category</a>

                       </td>
                   </tr>


                               <?php
                           }


                       }
                       else
                       {
                           //we donot have data in database
                           //display message inside table
                           ?>
                           <tr>
                               <td colspan="6">
                                   <div>No category added</div>
                               </td>
                           </tr>
                           <?php
                       }
                       ?>
                   
               </table>

                 </div>
             </div>


             <!-- Footer section starts-->
             <div class="footer">
        <div class="wrapper">
                <p class="text-center">
                    2021 All rights reserved. Developed By<a href="#">Muhammad Umair</a>
                </p>

                </div>
            

        </div>
    </body>
</html>