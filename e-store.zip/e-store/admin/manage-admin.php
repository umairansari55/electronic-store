<?php
//include('login-check.php');
?>
<html>
    <head>
        <title>Electronic Store Website - Home Page</title>
        <link rel="stylesheet" href="../css/admin.css">
    </head>
    <body>
        <!-- Product section starts-->
        <div class="product text-center">
            <div class="wrapper">
                <ul>
                    <li><a href="index.php">&#9750 Home</a></li>
                    <li><a href="manage-admin.php">&#10020 Admin</a></li>
                    <li><a href="manage-category.php">&#9870 Category</a></li>
                    <li><a href="manage-product.php">&#9738 Product</a></li>
                    <li><a href="manage-order.php">&#9743Order</a></li>
                    <li><a href="logout.php">&#9737 Logout</a></li>
                </ul>
                

            </div>


        </div>

        <!-- Main-content section starts-->
        <div class="main-content">
        <div class="wrapper">
                <h1>Manage Admin</h1>
                <br>
                <br>
                
               <a href="add-admin.php" class="btn-primary">Add Admin</a>
                <br>
                <br>
                <br>
                <table class="tbl-full">
                   <tr>
                       <th>S.No</th>
                       <th>Full Name</th>
                       <th>Username</th>
                       <th>Actions</th>
                   </tr>
                 
                   <?php
                    $conn = mysqli_connect('localhost','root','') or die(mysqli_error()); //Database connection
                    $db_select = mysqli_select_db($conn,'estore-order') or die(mysqli_error()); 
                   //Query to get all admin
                   $sql = "SELECT * FROM tbl_admin";
                   //Execute the query
                   $res = mysqli_query($conn, $sql);
                   //Check whether the query is executed or not
                   if($res==TRUE)
                   {
                       //count row to check whether we have data in database or not
                       $count = mysqli_num_rows($res); //functin to get all rows in database

                       $sn=1; //create a variable and assign the value

                       //check the number of rows
                       if($count>0)
                       {
                           //we have data in database
                           while($rows=mysqli_fetch_assoc($res))
                           {
                               //using while loop to get all the data from database
                               //and while looop will run as long we have data in database

                               //get indivisual data
                               $id = $rows['id'];
                               $full_name = $rows['full_name'];
                               $username = $rows['username'];

                               //display the values in our table
                               ?>

                               <tr>
                                   <td><?php echo $sn++;?>.</td>
                                   <td><?php echo $full_name;?></td>
                                   <td><?php echo $username;?></td>
                                   <td>
                                    <a href="<?php echo "http://localhost/e-store/"; ?>admin/update-password.php?id=<?php echo $id; ?>" class="btn-primary">Change Password</a>
                                   <a href="<?php echo "http://localhost/e-store/"; ?>admin/update-admin.php?id=<?php echo $id; ?>" class="btn-secondary">Update Admin</a>
                                   <a href="<?php echo "http://localhost/e-store/"; ?>admin/delete-admin.php?id=<?php echo $id; ?>" class="btn-danger">Delete Admin</a>
                                   </td>
                               </tr>
                               <?php

                           }
                       }
                       else
                       {
                           //we donot have data in database
                       }
                   }
                   ?>
               </table>

                </div>
            

        </div>
        <!-- Footer section starts-->
        <div class="footer">
        <div class="wrapper">
                <p class="text-center">
                    2021 All rights reserved. Developed By<a href="#">Muhammad Umair</a>
                </p>

                </div>
            

        </div>
    </body>
</html>
