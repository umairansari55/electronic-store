<?php

//Get data from form
session_start();
$conn = mysqli_connect('localhost','root','') or die(mysqli_error()); //Database connection
$db_select = mysqli_select_db($conn,'estore-order') or die(mysqli_error()); //database selection
//Destroy the session
session_destroy();
//redirect to login page
header("location:".'http://localhost/e-store/');




?>