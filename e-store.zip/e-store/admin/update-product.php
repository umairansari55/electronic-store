<html>
    <head>
        <title>Electronic Store Website - Home Page</title>
        <link rel="stylesheet" href="../css/admin.css">
    </head>
    <body>
        <!-- Product section starts-->
        <div class="product text-center">
            <div class="wrapper">
                <ul>
                    <li><a href="index.php">&#9750 Home</a></li>
                    <li><a href="manage-admin.php">&#10020 Admin</a></li>
                    <li><a href="manage-category.php">&#9870 Category</a></li>
                    <li><a href="manage-product.php">&#9738 Product</a></li>
                    <li><a href="manage-order.php">&#9743Order</a></li>
                    <li><a href="logout.php">&#9737 Logout</a></li>

                </ul>
                

            </div>


        </div>
        <?php
            //check whether the id is set or not
            if(isset($_GET['id']))
            {
                //get all details
                $id = $_GET['id'];
                $conn = mysqli_connect('localhost','root','') or die(mysqli_error()); //Database connection
                $db_select = mysqli_select_db($conn,'estore-order') or die(mysqli_error());
                //create SQL query 
                $sql2 = "SELECT * FROM tbl_product WHERE id=$id";
                //execute the query
                $res2 = mysqli_query($conn, $sql2);
                //get the value based on query executed
                $row2=mysqli_fetch_assoc($res2);
                //get the indivisual values
                //Get data from form
                $title = $row2['title']; 
                $description = $row2['description']; 
                $price = $row2['price'];
                $current_image = $row2['image_name'];
                $current_category = $row2['category_id'];
                $featured = $row2['featured'];
                $active = $row2['active'];
            }
            else
            {
                //redirect to manage product
                header('location:'."http://localhost/e-store/".'admin/manage-product.php');
            }
        ?>
         <!-- Main-content section starts-->
         <div class="main-content">
            <div class="wrapper">
                <h1>Update Product</h1>
                <br><br>
                <form action="" method="POST" enctype="multipart/form-data">
                <table class="tbl-30">
                   <tr>
                        <td>Title:</td>
                        <td>
                            <input type="text" name="title" value="<?php echo $title;?>">
                        </td>
                    </tr>
                    <tr>
                            <td>
                                Description:
                            </td>
                            <td>
                                <textarea name="description" cols="30" rows="5"><?php echo $description;?></textarea>
                            </td>
                    </tr>
                    <tr>
                            <td>Price:</td>
                            <td>
                                <input type="number" name="price" value="<?php echo $price;?>">
                            </td>
                    </tr>
                    <tr>
                        <td>CurrentImage:</td>
                        <td>
                            <?php
                                 if($current_image == "")
                                 {
                                     //image not availabe
                                 }
                                 else
                                 {
                                     //image available
                                     ?>

                                     <img src="<?php echo 'http://localhost/e-store/';?>images/product/<?php echo $current_image;?>" width="100px">

                                     <?php

                                 }
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <td>New Image</td>
                        <td>
                            <input type="file" name="image">
                        </td>
                    </tr>
                    <tr>
                        <td>Category:</td>
                        <td>
                            <select name="category">
                            <?php
                                $conn = mysqli_connect('localhost','root','') or die(mysqli_error()); //Database connection
                                $db_select = mysqli_select_db($conn,'estore-order') or die(mysqli_error());
                                //create SQL query 
                                $sql = "SELECT * FROM tbl_category WHERE active='Yes'";
                                //execute the query
                                $res = mysqli_query($conn, $sql);
                                //check whether the data is available or not
                                $count = mysqli_num_rows($res);

                                //check whether category is available or not
                                if($count>0)
                                {
                                    //category available
                                    while($row=mysqli_fetch_assoc($res))
                                    {
                                        $category_title = $row['title'];
                                        $category_id = $row['id'];

                                        //echo "<option value='$category_id'>$category_title</option>";
                                        ?>
                                            <option <?php if($current_category==$category_id){echo "selected";}?> value="<?php echo $category_id;?>"><?php echo $category_title;?></option>
                                        <?php
                                    }

                                }
                                else
                                {
                                    //category not available
                                    echo "<option value='0'>Category not Available.</option>";
                                    
                                }
                            ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                            <td>Featured:</td>
                            <td>
                                <input <?php if($featured=="Yes"){echo "checked";} ?> type="radio" name="featured" value="Yes"> Yes
                                <input <?php if($featured=="No"){echo "checked";} ?> type="radio" name="featured" value="No"> No

                            </td>
                    </tr>
                        <tr>
                            <td>Active:</td>
                            <td>
                                <input <?php if($active=="Yes"){echo "checked";} ?> type="radio" name="active" value="Yes"> Yes
                                <input <?php if($active=="No"){echo "checked";} ?> type="radio" name="active" value="No"> No

                            </td>
                    </tr>
                    <tr>
                            <td colspan="2">
                                <input type="hidden" name="id" value="<?php echo $id; ?>">
                                <input type="hidden" name="current_image" value="<?php echo $current_image; ?>">
                                

                                <input type="submit" name="submit" value="Update Product" class="btn-secondary">
                                
                            </td>
                    </tr>

                </table>
                </form>
                <?php
                //Check whether the submit button is clicked or not
                if(isset($_POST['submit']))
                {
                    //echo "Button clicked";
                    //get all the values from form to update
                    $id = $_POST['id'];
                    $title = $_POST['title'];
                    $description = $_POST['description'];
                    $price = $_POST['price'];
                    $current_image = $_POST['current_image'];
                    $category = $_POST['category'];
                    $featured = $_POST['featured'];
                    $active= $_POST['active'];
                    //updating new image if selected
                    //check whether image is selected or not
                    if(isset($_FILES['image']['name']))
                    {
                        //upload button is clicked
                        $image_name=$_FILES['image']['name'];
                        //check whether the image is available or not
                        if($image_name!="")
                        {
                            //image available
                            //upload the image
                            //auto rename our Image
                            //get the extension of our image (jpg, png, gif, etc)
                            $exp=explode('.' , $image_name);
                            $ext=end($exp);
                            $image_name = "Product_Name_".rand(0000, 9999).'.'.$ext;
                            $src_path=$_FILES['image']['tmp_name'];
                            $dest_path="../images/product/".$image_name;
                            //finally upload the image
                            $upload= move_uploaded_file($src_path, $dest_path);
                            //check whether is uploaded or not
                            if($upload==false)
                            {
                                //failed to upload
                                //redirect to manage product page
                                header("location:".'http://localhost/e-store/'.'admin/manage-product.php');
                                die(); //stop the process
                            }
                            //remove the current image if image is available
                            if($current_image!="")
                            {
                                //current image is available
                                //remove the image
                                $remove_path = "../images/product/".$current_image;
                                $remove= unlink($remove_path);
                                //check whether the image is removed or not
                                if($remove==false)
                                {
                                    //failed to remove the image
                                    //redirect to manage category page
                                    header("location:".'http://localhost/e-store/'.'admin/manage-product.php');
                                    die();
                                }
                            }
                        }
                        else
                        {
                            $image_name = $current_image;
                        }
                    }
                    else
                    {
                        $image_name = $current_image;
                    }
                    //remove the current image if image is available
                    //update the Database
                    $conn = mysqli_connect('localhost','root','') or die(mysqli_error()); //Database connection
                    $db_select = mysqli_select_db($conn,'estore-order') or die(mysqli_error());
                    $sql3 = "UPDATE tbl_product SET
                    title = '$title',
                    description = '$description',
                    price = $price,
                    image_name = '$image_name',
                    category_id = '$category_id',
                    featured = '$featured',
                    active = '$active'
                    WHERE id = $id
                    ";
                    //execute the query
                    $res3 = mysqli_query($conn, $sql3);
                    //check whether the query is executed or not
                    //if($res3==true)
                    //{
                    //query executed
                      //header('location:'."http://localhost/e-store/".'admin/manage-product.php');
                    //}
                    //else
                    //{
                        //failed to execute query
                    //}


                }
                ?>
            </div>
        </div>
        <!-- Footer section starts-->
        <div class="footer">
        <div class="wrapper">
                <p class="text-center">
                    2021 All rights reserved. Developed By<a href="#">Muhammad Umair</a>
                </p>

                </div>
            

        </div>
    </body>
</html>