<html>
    <head>
        <title>Electronic Store Website - Home Page</title>
        <link rel="stylesheet" href="../css/admin.css">
    </head>
    <body>
        <!-- Product section starts-->
        <div class="product text-center">
            <div class="wrapper">
                <ul>
                    <li><a href="index.php">&#9750 Home</a></li>
                    <li><a href="manage-admin.php">&#10020 Admin</a></li>
                    <li><a href="manage-category.php">&#9870 Category</a></li>
                    <li><a href="manage-product.php">&#9738 Product</a></li>
                    <li><a href="manage-order.php">&#9743Order</a></li>
                    <li><a href="logout.php">&#9737 Logout</a></li>

                </ul>
                

            </div>


        </div>
        <div class="main-content">
            <div class="wrapper">
                <h1>Add Product</h1>
                <br>
                <form action="" method="POST" enctype="multipart/form-data">
                    <table class="tbl-30">
                    <tr>
                            <td>Title:</td>
                            <td>
                                <input type="text" name="title" placeholder="Product Title">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                Description:
                            </td>
                            <td>
                                <textarea name="description" cols="30" rows="5" placeholder="Product Description"></textarea>
                            </td>
                        </tr>
                        <tr>
                            <td>Price:</td>
                            <td>
                                <input type="number" name="price">
                            </td>
                        </tr>
                        <tr>
                            <td>SelectImage</td>
                            <td>
                                <input type="file" name="image">
                            </td>
                        </tr>
                        <tr>
                            <td>Category</td>
                            <td>
                                <select name="category">

                                <?php
                                    //create PHP code to display all categories from database
                                    //create SQL query to gel all active categories from database
                                    $sql = "SELECT * FROM tbl_category WHERE active='Yes'";
                                    $conn = mysqli_connect('localhost','root','') or die(mysqli_error()); //Database connection
                                    $db_select = mysqli_select_db($conn,'estore-order') or die(mysqli_error()); 
                                    $res = mysqli_query($conn, $sql);
                                    //count rows
                                    $count= mysqli_num_rows($res);
                                    //check whether we have data in database or not
                                    if($count>0)
                                    {
                                        //we have categories 
                                        while($row=mysqli_fetch_assoc($res))
                                        {
                                            //get the details of category
                                            
                                            $id = $row['id'];
                                            $title = $row['title'];
                                            ?>
                                            <option value="<?php echo $id;?>"><?php echo $title;?></option>
                                            <?php
                                        }
                                    }
                                    else
                                    {
                                        //we donot have categories
                                        ?>

                                        <option value="0">No Category Found</option>
                                        <?php
                                    }
                                    //display on dropdown   
                                
                                ?>
                                    
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td>Featured:</td>
                            <td>
                                <input type="radio" name="featured" value="Yes"> Yes
                                <input type="radio" name="featured" value="No"> No

                            </td>
                        </tr>
                        <tr>
                            <td>Active:</td>
                            <td>
                                <input type="radio" name="active" value="Yes"> Yes
                                <input type="radio" name="active" value="No"> No

                            </td>
                        </tr>
                        <tr>
                            <td colspan="2">
                                <input type="submit" name="submit" value="Add Product" class="btn-secondary">
                                
                            </td>
                        </tr>
                    </table>


               </form>
               <?php
                    //Process the value from form and save it in database
                    //Check whether the submit button is clicked or not

                    if(isset($_POST['submit']))
                    {
                        //Button clicked
                        //"Button Clicked";

                        //Get data from form
                        $title = $_POST['title']; 
                        $description = $_POST['description']; 
                        $price = $_POST['price'];
                        $category = $_POST['category'];

                        //for radio input we need to check whether the button is selected or not
                        if(isset($_POST['featured']))
                        {
                            //get value from form
                            $featured = $_POST['featured'];
                        }
                        else
                        {
                            //set the default value
                            $featured = "No";
                        }
                        if(isset($_POST['active']))
                        {
                            //get value from form
                            $active = $_POST['active'];
                        }
                        else
                        {
                            //set the default value
                            $active = "No";
                        }                    
                        //upload the image if selected
                        if(isset($_FILES['image']['name']))
                        {
                            //upload the image
                            //to upload image we need image name source path and destination name
                            $image_name=$_FILES['image']['name'];
                            //upload image only if image is selected
                            if($image_name!="")
                            {

                            
                                    //auto rename our Image
                                    //get the extension of our image (jpg, png, gif, etc)
                                    $ext =explode('.' , $image_name);
                                    $file_extension = end($ext);
                                    //rename the image 
                                    $image_name = "Product-Name-".rand(0000, 9999).".".$file_extension;
                                    //upload the image
                                    //get source path and destination path
                                    //source path is the current location of the image
                                    $src = $_FILES['image']['tmp_name'];
                                    //Destination path for image to be uploaded
                                    $dst = "../images/product/".$image_name;

                                    //finallly upload image
                                    $upload= move_uploaded_file($src, $dst);

                                    //check whether is uploaded or not
                                    //and if image is not uploaded then we will stop the process and redirect to homepage
                                    if($upload==false)
                                    {
                                        header("location:".'http://localhost/e-store/'.'admin/add-product.php');
                                        //stop the process
                                        die();                
                                    }
                            }

                        }
                        else
                        {
                            //do not upload the image and set image_name value blank
                            $image_name = "";
                        }

                        //insert into database
                        //SQL query to save data into database
                        $sql2 = "INSERT INTO tbl_product SET
                        title = '$title',
                        description = '$description',
                        price =$price,
                        image_name= '$image_name',
                        category_id = $category,
                        featured = '$featured',
                        active = '$active'
                        ";
                        $res2 = mysqli_query($conn, $sql2);
                        //Check whether the (query is Executed) data is inserted or not and display appropriate mesaage
                        //redirect to Product page
                        if($res2==TRUE)
                        {
                            //Redirect page to manage-admin
                            header("location:".'http://localhost/e-store/'.'admin/manage-product.php');

                        }
                        else
                        {
                            //Redirect page to add-admin
                            header("location:".'http://localhost/e-store/'.'admin/add-product.php');
                        }

                        
                    }
                   ?>



<br>
            </div>
        </div>

        <!-- Footer section starts-->
        <div class="footer">
        <div class="wrapper">
                <p class="text-center">
                    2021 All rights reserved. Developed By<a href="#">Muhammad Umair</a>
                </p>

                </div>
            

        </div>
    </body>
</html>