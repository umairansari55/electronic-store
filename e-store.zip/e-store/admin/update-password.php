<?php
//include('login-check.php');
?>
<html>
    <head>
        <title>Electronic Store Website - Home Page</title>
        <link rel="stylesheet" href="../css/admin.css">
    </head>
    <body>
        <!-- Product section starts-->
        <div class="product text-center">
            <div class="wrapper">
                <ul>
                    <li><a href="index.php">&#9750 Home</a></li>
                    <li><a href="manage-admin.php">&#10020 Admin</a></li>
                    <li><a href="manage-category.php">&#9870 Category</a></li>
                    <li><a href="manage-product.php">&#9738 Product</a></li>
                    <li><a href="manage-order.php">&#9743Order</a></li>
                    <li><a href="logout.php">&#9737 Logout</a></li>
                </ul>
                

            </div>


        </div>

        <!-- Main-content section starts-->
        <div class="main-content">
        <div class="wrapper">
                <h1>Change Password</h1>
                <br>
                <br>

                <?php
                if(isset($_GET['id']))
                {
                    $id=$_GET['id'];
                }
               
               
               ?>


                <form action="" method="POST">
                    <table class="tbl-30">
                        <tr>
                            <td>Current Password:</td>
                            <td>
                                <input type="password" name="current_password" placeholder="Current Password">
                            </td>
                        </tr>

                        <tr>
                            <td>New Password:</td>
                            <td>
                                <input type="password" name="new_password" placeholder="New Password">
                            </td>        
                            
                        </tr>
                        <tr>
                            <td>Confirm Password</td>
                            <td>
                                <input type="password" name="confirm_password" placeholder="Confirm Password">
                            </td>
                        </tr>

                        <tr>
                            <td colspan="2">
                                <input type="hidden" name="id" value="<?php echo $id;?>">
                                <input type="submit" name="submit" value="Change Password" class="btn-secondary">
                            </td>
                        </tr>



                        </table>

                </form>
        </div>
        </div>

        <?php
        //check whether the submit button is clicked or not
        if(isset($_POST['submit']))
        {
           //echo "clicked";

           //get data from form
           $id=$_POST['id'];
           $current_password=md5($_POST['current_password']);
           $new_password=md5($_POST['new_password']);
           $confirm_password=md5($_POST['confirm_password']);

           $conn = mysqli_connect('localhost','root','') or die(mysqli_error()); //Database connection
           $db_select = mysqli_select_db($conn,'estore-order') or die(mysqli_error()); 
           //check whether the user with current ID ad current password exists or nor
           $sql = "SELECT * FROM tbl_admin WHERE id=$id AND PASSWORD='$current_password'";
           //execute the query
           $res = mysqli_query($conn, $sql);
           if($res==TRUE)
           {
               //check whether the data is available or not
               $count=mysqli_num_rows($res);
               if($count==1)
               {
                   //user exist and password can be changed
                   //echo "user found";

                   //check whether the new password and confirm password or not
                   if($new_password==$confirm_password)
                   {
                       //update the password
                       //echo "Password Match";
                       $sql2= "UPDATE tbl_admin SET
                          password='$new_password'
                          WHERE id='$id'
                       ";
                       //execute the query
                       $res2= mysqli_query($conn, $sql2);

                       //check whether the queryis executed or not
                       if($res2==TRUE)
                       {
                           //redirect to manage admin
                             header('location:'."http://localhost/e-store/".'admin/manage-admin.php');
                       }
                       else
                       {
                          //donot redirect to manage admin 
                       }
                   }
                   else
                   {
                       // redirect to manage admin page
                       header('location:'."http://localhost/e-store/".'admin/manage-admin.php');

                   }
                  
               }
               else
               {
                   //user does not exist
                   header('location:'."http://localhost/e-store/".'admin/manage-admin.php');


               }

           }


           //check whether the new password and confirm password match or not

           //change password if all above is true
        }
        
        ?>


         <!-- Footer section starts-->
         <div class="footer">
        <div class="wrapper">
                <p class="text-center">
                    2021 All rights reserved. Developed By<a href="#">Muhammad Umair</a>
                </p>

                </div>
            

        </div>
    </body>
</html>